# Client Placement Portal

Online portal for consultants and sales team members to use in relation to posting, finding and applying for client placement opportunities.