package com.fdmgroup.cppapi.controllers;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fdmgroup.cppapi.exceptions.AccountManagerNotFoundException;
import com.fdmgroup.cppapi.exceptions.InvalidPasswordException;
import com.fdmgroup.cppapi.models.AccountManager;
import com.fdmgroup.cppapi.services.AccountManagerServiceImplemented;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/api/v1/account-managers")
public class AccountManagerController {
	private AccountManagerServiceImplemented accountManagerService;

	public AccountManagerController(AccountManagerServiceImplemented accountManagerService) {
		this.accountManagerService = accountManagerService;
	}

	@Operation(summary = "Create a new accountManager")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "201", description = "AccountManager created successfully", headers = {
			@Header(name = "location", description = "Uri to access to create accountManager")
		}, content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)
		})
	})
	@CrossOrigin(origins = "http://localhost:3000")
	@PostMapping
	public ResponseEntity<?> addAccountManager(@Valid @RequestBody AccountManager accountManager, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			Map<String, String> errors = new HashMap<>();
			for (FieldError error : bindingResult.getFieldErrors()) {
				errors.put(error.getField(), error.getDefaultMessage());
			}
			return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(this.accountManagerService.addAccountManager(accountManager), HttpStatus.CREATED);
	}

	@Operation(summary = "Find All AccountManagers")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Find all accountManagers successfully", headers = {
			@Header(name = "location", description = "Uri to access to find all accountManagers")
		}, content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)
		})
	})
	@CrossOrigin(origins = "http://localhost:3000")
	@GetMapping
	public ResponseEntity<?> getAllAccountManagers() {
		return new ResponseEntity<>(this.accountManagerService.getAllAccountManagers(), HttpStatus.OK);
	}

	@Operation(summary = "Update an AccountManager")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "AccountManager updated successfully", headers = {
			@Header(name = "location", description = "Uri to access to update accountManager")
		}, content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)
		})
	})
	@CrossOrigin(origins = "http://localhost:3000")
	@PutMapping
	public ResponseEntity<?> updateAccountManager(@RequestBody AccountManager accountManager) {
		return new ResponseEntity<>(this.accountManagerService.updateAccountManager(accountManager), HttpStatus.OK);
	}

	@Operation(summary = "Find accountManager by id")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "find an accountManager successfully", headers = {
			@Header(name = "location", description = "Uri to access to find accountManager")
		}, content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)
		})
	})
	@CrossOrigin(origins = "http://localhost:3000")
	@GetMapping("/{id}")
	public ResponseEntity<?> findAccountManagerById(@PathVariable Long id) {
		AccountManager accountManager = this.accountManagerService.findAccountManagerById(id);
		if (accountManager == null) {
			return new ResponseEntity<>(
					new AccountManagerNotFoundException(id.toString()).getMessage(),
					HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(accountManager, HttpStatus.OK);
	}

	@CrossOrigin(origins = "http://localhost:3000")
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteAccountManagerById(@PathVariable Long id) {
		AccountManager accountManager = this.accountManagerService.findAccountManagerById(id);
		if (accountManager == null) {
			return new ResponseEntity<>(
					new AccountManagerNotFoundException(id.toString()).getMessage(),
					HttpStatus.NOT_FOUND);
		}
		this.accountManagerService.deleteAccountManagerById(id);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@Operation(summary = "Login accountManager by username and password")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Logged In AccountManager Successfully", headers = {
			@Header(name = "location", description = "Uri to login an accountManager")
		}, content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)
		})
	})
	@CrossOrigin(origins = "http://localhost:3000")
	@GetMapping("/login/{email}&{password}")
	public ResponseEntity<?> loginAccountManager(@PathVariable String email, @PathVariable String password) {
		AccountManager accountManager = this.accountManagerService.findAccountManagerByEmail(email);
		if (accountManager == null) {
			return new ResponseEntity<>(
					new AccountManagerNotFoundException(email).getMessage(),
					HttpStatus.NOT_FOUND);
		} else {
			if (accountManager.getPassword().compareTo(password) == 0) {
				return new ResponseEntity<>(accountManager, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(
					new InvalidPasswordException(password).getMessage(),
					HttpStatus.FORBIDDEN);
			}
		}
	}
}