package com.fdmgroup.cppapi.services;


import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.fdmgroup.cppapi.models.AccountManager;
import com.fdmgroup.cppapi.repositories.AccountManagerRepository;

@Service
public class AccountManagerServiceImplemented implements AccountManagerService {

    private AccountManagerRepository accountManagerRepository;

	public AccountManagerServiceImplemented(AccountManagerRepository accountManagerRepository) {
		this.accountManagerRepository = accountManagerRepository;
	}

    @Override
    public AccountManager addAccountManager(AccountManager accountManager) {
        // No id provided so will perform insert statement
        return this.accountManagerRepository.save(accountManager);
    }

    @Override
    public AccountManager updateAccountManager(AccountManager accountManager) {
        // Id provided so will perform update statement
        return this.accountManagerRepository.save(accountManager);
    }

    @Override
    public void deleteAccountManagerById(Long id) {
        this.accountManagerRepository.deleteById(id);
    }

    @Override
    public Iterable<AccountManager> getAllAccountManagers() {
        return this.accountManagerRepository.findAll();
    }

    @Override
    public AccountManager findAccountManagerById(Long id) {
        return this.accountManagerRepository.findById(id).orElse(null);
    }

    @Override
    public AccountManager findAccountManagerByEmail(String email) {
        return this.accountManagerRepository.findByEmail(email).orElse(null);
    }
}
