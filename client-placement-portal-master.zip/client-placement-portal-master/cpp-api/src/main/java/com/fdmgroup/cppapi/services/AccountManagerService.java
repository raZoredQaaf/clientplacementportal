package com.fdmgroup.cppapi.services;


import com.fdmgroup.cppapi.models.AccountManager;


public interface AccountManagerService {
    
    AccountManager addAccountManager(AccountManager accountManager);

	AccountManager updateAccountManager(AccountManager accountManager);

	void deleteAccountManagerById(Long id);

    Iterable<AccountManager> getAllAccountManagers();

    AccountManager findAccountManagerById(Long id);

    AccountManager findAccountManagerByEmail(String email);

    
}
