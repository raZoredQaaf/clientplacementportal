package com.fdmgroup.cppapi.models;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Builder;

@Entity
public class Consultant extends User {
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name="consultant_interests", joinColumns=@JoinColumn(name="consultant_id"), inverseJoinColumns=@JoinColumn(name="interest_id"))
	@JsonIgnore
	private List<Interest> interests;

	private String geoFlexArea;

	@OneToOne(cascade = CascadeType.ALL)
	private Stream trainingStream;

	private String cvLink;

	private String status;

	public Consultant() {}
	
	@Builder
	public Consultant(String email, String password, Contact contactDetails, String geoFlexArea, Stream trainingStream, String cvLink, String status) {
		super(email, password, contactDetails);
		this.geoFlexArea = geoFlexArea;
		this.trainingStream = trainingStream;
		this.cvLink = cvLink;
		this.status = status;
	}

	public List<Interest> getInterests() {
		return interests;
	}

	public void setInterests(List<Interest> interests) {
		this.interests = interests;
	}

	public String getGeoFlexArea() {
		return geoFlexArea;
	}

	public void setGeoFlexArea(String geoFlexArea) {
		this.geoFlexArea = geoFlexArea;
	}

	public Stream getTrainingStream() {
		return trainingStream;
	}

	public void setTrainingStream(Stream trainingStream) {
		this.trainingStream = trainingStream;
	}

	public String getCvLink() {
		return cvLink;
	}

	public void setCvLink(String cvLink) {
		this.cvLink = cvLink;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Consultant: [email=" + getEmail() + ", contact details=" + getContactDetails().toString() + "]";
	}

}
