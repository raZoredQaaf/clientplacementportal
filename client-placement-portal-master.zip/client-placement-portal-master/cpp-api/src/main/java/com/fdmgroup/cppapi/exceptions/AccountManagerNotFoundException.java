package com.fdmgroup.cppapi.exceptions;

public class AccountManagerNotFoundException extends RuntimeException {

    public AccountManagerNotFoundException(String email) {
        super("Could not find account: " + email);
    }
}