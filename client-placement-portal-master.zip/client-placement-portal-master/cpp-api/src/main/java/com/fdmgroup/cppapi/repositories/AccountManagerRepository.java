package com.fdmgroup.cppapi.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fdmgroup.cppapi.models.AccountManager;

@Repository
public interface AccountManagerRepository extends JpaRepository<AccountManager, Long> {

    /**
     * @param username This is the accountmanagers username
     * 
     * Uses a @Query to select the results from the repository that match the username param exactly
     */
    @Query("select accountmanager from AccountManager accountmanager where accountmanager.email = ?1")
    public Optional<AccountManager> findByEmail(String username);

}

