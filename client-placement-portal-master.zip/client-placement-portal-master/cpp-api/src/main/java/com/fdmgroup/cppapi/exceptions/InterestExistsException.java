package com.fdmgroup.cppapi.exceptions;

public class InterestExistsException extends RuntimeException {

    public InterestExistsException(String id) {
        super("Interest already exists");
    }
}