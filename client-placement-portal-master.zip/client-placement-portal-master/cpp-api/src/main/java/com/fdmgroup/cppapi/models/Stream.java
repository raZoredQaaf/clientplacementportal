package com.fdmgroup.cppapi.models;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Stream {
    @Id
    private int id;

    private String name;

    private boolean technical;

    public Stream () {};

    public Stream(String name, boolean technical) {
        this.name = name;
        this.technical = technical;
    }
}
