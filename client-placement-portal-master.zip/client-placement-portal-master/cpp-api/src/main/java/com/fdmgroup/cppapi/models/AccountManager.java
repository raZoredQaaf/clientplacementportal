package com.fdmgroup.cppapi.models;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;


import lombok.Builder;

@Entity
public class AccountManager extends User {
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name="accountmanagers_clients", joinColumns=@JoinColumn(name="accountmanager_id"), inverseJoinColumns=@JoinColumn(name="client_id"))
	private List<Client> clients;

	private String office;

	private String sector;

	public AccountManager() {}
	
	@Builder
	public AccountManager(String email, String password, Contact contactDetails, String office, String sector) {
		super(email, password, contactDetails);
		this.office = office;
		this.sector = sector;
	}
	
	@Override
	public String toString() {
		return "Consultant: [email=" + getEmail() + ", contact details=" + getContactDetails().toString() + "]";
	}

	public List<Client> getClients() {
		return clients;
	}

	public void setClients(List<Client> clients) {
		this.clients = clients;
	}

	public String getOffice() {
		return office;
	}

	public void setOffice(String office) {
		this.office = office;
	}

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

}
