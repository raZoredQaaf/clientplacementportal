package com.fdmgroup.cppapi.models;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Interest {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "interest_gen")
	@SequenceGenerator(name = "interest_gen", sequenceName = "interest_seq", allocationSize = 1)
    private Long id;

    @OneToOne(cascade = CascadeType.MERGE)
    private Consultant consultant;

    @OneToOne(cascade = CascadeType.MERGE)
    private Placement placement;

    private String status;

    private String reason;

    public Interest () {}

    public Interest(Consultant consultant, Placement placement, String status, String reason) {
        this.consultant = consultant;
        this.placement = placement;
        this.status = status;
        this.reason = reason;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Consultant getConsultant() {
        return consultant;
    }

    public void setConsultant(Consultant consultant) {
        this.consultant = consultant;
    }

    public Placement getPlacement() {
        return placement;
    }

    public void setPlacement(Placement placement) {
        this.placement = placement;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
