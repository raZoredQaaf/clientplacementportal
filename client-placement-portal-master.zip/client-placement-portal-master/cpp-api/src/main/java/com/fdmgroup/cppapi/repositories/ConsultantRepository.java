package com.fdmgroup.cppapi.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fdmgroup.cppapi.models.Consultant;

@Repository
public interface ConsultantRepository extends JpaRepository<Consultant, Long> {

    /**
     * @param username This is the consultants username
     * 
     * Uses a @Query to select the results from the repository that match the username param exactly
     */
    @Query("select consultant from Consultant consultant where consultant.email = ?1")
    public Optional<Consultant> findByEmail(String email);

    @Query("select consultant from Consultant consultant where consultant.email LIKE %?1%")
    public Iterable<Consultant> searchByEmail(String email);

    @Query("select consultant from Consultant consultant where consultant.contactDetails.firstName LIKE %?1%")
	public Iterable<Consultant> searchByFirstName(String firstName);

    @Query("select consultant from Consultant consultant where consultant.contactDetails.lastName LIKE %?1%")
	public Iterable<Consultant> searchByLastName(String lastName);
}

