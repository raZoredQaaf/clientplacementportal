package com.fdmgroup.cppapi.exceptions;

public class InvalidPasswordException extends RuntimeException {

    public InvalidPasswordException(String password) {
        super("Email and Password did not match");
    }
}