class Placement {

    constructor(obj) {
      obj = obj != null ? obj : {}
      this.firstName = obj.firstName != null ? obj.firstName : ''
      this.lastName = obj.lastName != null ? obj.lastName : ''
    }
  
  }
  