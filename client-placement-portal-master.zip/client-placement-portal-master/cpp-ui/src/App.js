import './App.css';
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { createTheme, ThemeProvider } from '@mui/material';
import { red, grey } from '@mui/material/colors';
import ConsultantNavBar from './components/main/consultantNavbar.component';
import AccountManagerNavBar from './components/main/accountManagerNavbar.component';
import Access from './components/login/access.component.js';
import { ProtectedRoute } from './config/protectedRoute';
import { AuthProvider } from './config/auth';
import ConsultantList from './components/account-manager/consultant/consultant-list/consultant-list.component';
import AccountManagerPlacementList from './components/account-manager/placement/placement-list/account-manager-placement-list.component';
import PlacementCreate from './components/account-manager/placement/placement-create/placement-create.component';
import InterestList from './components/consultant/interest/interest-list/interest-list.component';
import ConsultantPlacementList from './components/consultant/placement/placement-list/cosultant-placement-list.component';
import ProfileDisplay from './components/consultant/profile/profile-display.component';

function App() {

  const theme = createTheme({
    typography: {
      fontFamily: [   
        '-apple-system',
      'BlinkMacSystemFont',
      '"Segoe UI"',
      'Roboto',
      '"Helvetica Neue"',
      'Arial',
      'sans-serif',
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',       
      ].join(','),
    },
    status: {
      danger: red[500],
    },
    palette: {
      primary: {
        light:'#694BDF',
        main: '#3D07FF',
        dark: grey[900]
        
      }
    }
  });

  return (
    <AuthProvider>
      <ThemeProvider theme={theme}>
        <div className="App">
        <Routes>
          <Route path="/" element={
            <Access />
          }>
          </Route>
          <Route
            path="/Account-Manager/Consultants"
            element={
              <ProtectedRoute>
                <div>
                  <AccountManagerNavBar />
                  <ConsultantList />
                </div>
              </ProtectedRoute>
            }>
          </Route>
          <Route
            path="/Account-Manager/Placements"
            element={
              <ProtectedRoute>
                <div>
                  <AccountManagerNavBar />
                  <AccountManagerPlacementList />
                </div>
              </ProtectedRoute>
            }>
          </Route>
          <Route
            path="/Account-Manager/Create-Placement"
            element={
              <ProtectedRoute>
                <div>
                  <AccountManagerNavBar />
                  <PlacementCreate />
                </div>
              </ProtectedRoute>
            }>
          </Route>
          <Route
            path="/Consultant/Interests" 
            element={
              <ProtectedRoute>
                <div>
                  <ConsultantNavBar />
                  <InterestList />
                </div>
              </ProtectedRoute>
            }>
          </Route>
          <Route
            path="/Consultant/Placements" 
            element={
              <ProtectedRoute>
                <div>
                  <ConsultantNavBar />
                  <ConsultantPlacementList />
                </div>
              </ProtectedRoute>
            }>
          </Route>
          <Route
            path="/Consultant/Profile" 
            element={
              <ProtectedRoute>
                <div>
                  <ConsultantNavBar />
                  <ProfileDisplay />
                </div>
              </ProtectedRoute>
            }>
          </Route>
      </Routes>
    </div>
    </ThemeProvider>
    </AuthProvider>
  );
}

export default App;
