import { createContext, useContext, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useLocalStorage } from "./useLocalStorage";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [userId, setUserId] = useLocalStorage("userId", "");
    const [type, setType] = useLocalStorage("type", null);

    const navigate = useNavigate();

    // call this function when you want to authenticate the user
    const login = async (userId, type) => {
        console.log("Loggin in " + userId);
        setUserId(userId);
        setType(type);
        if (type === "consultant") {
            navigate("/Consultant/Interests");
        } else {
            navigate("/Account-Manager/Consultants");
        }
    };

    // call this function to sign out logged in user
    const logout = () => {
        setUserId(null);
        setType(null);
        navigate("/", { replace: true });
    };

    const value = useMemo(
        () => ({
        userId,
        type,
        login,
        logout,
        }),
        [userId, type]
    );
    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
    return useContext(AuthContext);
};