import { Navigate } from "react-router-dom";
import { useAuth } from "./auth";

export const ProtectedRoute = ({ children }) => {
    console.log("Got here: ");
    const { userId } = useAuth();
    console.log("Got here: " + userId);
    if (!userId) {
      // user is not authenticated
      return <Navigate to="/" />;
    }
    return children;
};