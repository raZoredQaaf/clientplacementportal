export const getBaseApiUrl = () => {
    return "http://localhost:8088/api/v1/";
}
