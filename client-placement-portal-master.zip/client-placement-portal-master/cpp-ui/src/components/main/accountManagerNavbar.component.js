import React from "react";
import { Link, useNavigate } from "react-router-dom";
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import Menu from '@mui/material/Menu';
import MenuIcon from '@mui/icons-material/Menu';
import Container from '@mui/material/Container';
import Button from '@mui/material/Button';
import MenuItem from '@mui/material/MenuItem';
import { Divider, Drawer, List } from "@mui/material";

import './navBarStyle.css';

const AccountManagerNavBar = () => {

    const navigate = useNavigate();

    const [anchorElNav, setAnchorElNav] = React.useState(null);

    const handleOpenNavMenu = (event) => {
    // setAnchorElNav(event.currentTarget);
    };

    const handleCloseNavMenu = (page) => {
        navigate(page);
        // setAnchorElNav(null);
    };

    const drawerWidth = 240;

    const [mobileOpen, setMobileOpen] = React.useState(false);

    const handleDrawerToggle = () => {
        setMobileOpen(!mobileOpen);
    };

    const drawer = (
        <Box onClick={handleDrawerToggle} sx={{ textAlign: 'center' }}>
            <Typography variant="h6" sx={{ my: 2 }}>
                Account Manager Placement Portal
            </Typography>
            <Divider />
            <List>
                <MenuItem href={"/Account-Manager/Placements"} key={"/Account-Manager/Placements"} onClick={() => handleCloseNavMenu("/Account-Manager/Placements")}>
                    <Typography textAlign="center">{"Placements"}</Typography>
                </MenuItem>
                <MenuItem href={"/Account-Manager/Consultants"} key={"/Account-Manager/Consultants"} onClick={() => handleCloseNavMenu("/Account-Manager/Consultants")}>
                    <Typography textAlign="center">{"Consultants"}</Typography>
                </MenuItem>
            </List>
        </Box>
    );

    return (
        <Box sx={{ display: 'flex' }}>
        <AppBar position="static">
            <Toolbar>
            <IconButton
                color="inherit"
                aria-label="open drawer"
                edge="start"
                onClick={handleDrawerToggle}
                sx={{ mr: 2, display: { sm: 'none' } }}
            >
                <MenuIcon />
            </IconButton>

            <div className="navBarLeft">
            <Typography
                variant="h6"
                sx={{ flexGrow: 1, display: { xs: 'none', sm: 'block' } }}
            >
                Account Manager Placement Portal
            </Typography>
            </div>
            <div className="navBarRight">
            <Box sx={{ display: { xs: 'none', sm: 'inline-block' } }}>
                <Button
                    key={"/Account-Manager/Placements"}
                    onClick={() => handleCloseNavMenu("/Account-Manager/Placements")}
                    sx={{ my: 2, color: 'white', display: 'inline-block' }}
                    >
                    {"Placements"}
                </Button>
                <Button
                    key={"/Account-Manager/Consultants"}
                    onClick={() => handleCloseNavMenu("/Account-Manager/Consultants")}
                    sx={{ my: 2, color: 'white', display: 'inline-block' }}
                    >
                    {"Consultants"}
                </Button>
            </Box>
            </div>
            </Toolbar>
        </AppBar>
        <Box component="nav">
            <Drawer
            container={document.body}
            variant="temporary"
            open={mobileOpen}
            onClose={handleDrawerToggle}
            ModalProps={{
                keepMounted: true, // Better open performance on mobile.
            }}
            sx={{
                display: { xs: 'block', sm: 'none' },
                '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth },
            }}
            >
            {drawer}
            </Drawer>
        </Box>
        </Box>
    );
}

export default AccountManagerNavBar;

