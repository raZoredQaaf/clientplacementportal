// import React from "react";
import { Link, useNavigate } from "react-router-dom";
import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import Menu from '@mui/material/Menu';
import MenuIcon from '@mui/icons-material/Menu';
import Container from '@mui/material/Container';
import Button from '@mui/material/Button';
import MenuItem from '@mui/material/MenuItem';
import { Divider, Drawer, List, ListItem, ListItemButton } from "@mui/material";

import './navBarStyle.css';

const ConsultantNavBar = () => {

    const navigate = useNavigate();

    const [anchorElNav, setAnchorElNav] = React.useState(null);

    const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
    };


    const handleCloseNavMenu = (page) => {
        navigate(page);
        setAnchorElNav(null);
    };

    const drawerWidth = 240;

    const [mobileOpen, setMobileOpen] = React.useState(false);

    const handleDrawerToggle = () => {
        setMobileOpen(!mobileOpen);
    };

    const drawer = (
        <Box onClick={handleDrawerToggle} sx={{ textAlign: 'center' }}>
            <Typography variant="h6" sx={{ my: 2 }}>
                Consultant Placement Portal
            </Typography>
            <Divider />
            <List>
                <MenuItem href={"/Consultant/Profile"} key={"/Consultant/Profile"} onClick={() => handleCloseNavMenu("/Consultant/Profile")}>
                    <Typography textAlign="center">{"Profile"}</Typography>
                </MenuItem>
                <MenuItem href={"/Consultant/Placements"} key={"/Consultant/Placements"} onClick={() => handleCloseNavMenu("/Consultant/Placements")}>
                    <Typography textAlign="center">{"Placements"}</Typography>
                </MenuItem>
                <MenuItem href={"/Consultant/Interests"} key={"/Consultant/Interests"} onClick={() => handleCloseNavMenu("/Consultant/Interests")}>
                    <Typography textAlign="center">{"Interests"}</Typography>
                </MenuItem>
            </List>
        </Box>
    );

    return (
        <Box sx={{ display: 'flex' }}>
        <AppBar position="static">
            <Toolbar>
            <IconButton
                color="inherit"
                aria-label="open drawer"
                edge="start"
                onClick={handleDrawerToggle}
                sx={{ mr: 2, display: { sm: 'none' } }}
            >
                <MenuIcon />
            </IconButton>
            
            <div className="navBarLeft">
                <Typography
                    variant="h6"
                    sx={{ flexGrow: 1, display: { xs: 'none', sm: 'block' } }}
                >
                    Consultant Placement Portal
                </Typography>
            </div>
            <div className="navBarRight">
            <Box sx={{ display: { xs: 'none', sm: 'inline-block' } }}>
                <Button
                    key={"/Consultant/Profile"}
                    onClick={() => handleCloseNavMenu("/Consultant/Profile")}
                    sx={{ my: 2, color: 'white', display: 'inline-block' }}
                    >
                    {"Profile"}
                    </Button>
                    <Button
                    key={"/Consultant/Placements"}
                    onClick={() => handleCloseNavMenu("/Consultant/Placements")}
                    sx={{ my: 2, color: 'white', display: 'inline-block' }}
                    >
                    {"Placements"}
                    </Button>
                    <Button
                    key={"/Consultant/Interests"}
                    onClick={() => handleCloseNavMenu("/Consultant/Interests")}
                    sx={{ my: 2, color: 'white', display: 'inline-block' }}
                    >
                    {"Interests"}
                    </Button>
            </Box>
            </div>
            
            </Toolbar>
        </AppBar>
        <Box component="nav">
            <Drawer
            container={document.body}
            variant="temporary"
            open={mobileOpen}
            onClose={handleDrawerToggle}
            ModalProps={{
                keepMounted: true, // Better open performance on mobile.
            }}
            sx={{
                display: { xs: 'block', sm: 'none' },
                '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth },
            }}
            >
            {drawer}
            </Drawer>
        </Box>
        </Box>
    );
}

export default ConsultantNavBar;
