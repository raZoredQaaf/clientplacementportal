import { Button, Card, CardActions, CardContent, Dialog, Typography } from "@mui/material";
import React, { useState } from "react";


const ConsultantDisplay = (props) => {

    const {consultant, onDelete} = props;

    // declare a new state variable for modal open
    const [openUpdate, setOpenUpdate] = useState(false);

    // function to handle modal open
    const handleUpdateOpen = () => {
        setOpenUpdate(true);
    };

    // function to handle modal close
    const handleUpdateClose = () => {
        setOpenUpdate(false);
    };

    return (
        <Card sx={{ minWidth: 275 }}>
        <CardContent>
            <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
            {consultant.contactDetails.firstName}
            </Typography>
            <Typography variant="h5" component="div">
            Name: <span className="consultant-item">{consultant.contactDetails.firstName + " " + consultant.contactDetails.lastName}</span>
            </Typography>
            <Typography sx={{ mb: 1.5 }} color="text.secondary">
            Username: <span className="consultant-item">{consultant.username}</span>
            </Typography>
            <Typography variant="body2">
            Email: <span className="consultant-item">{consultant.contactDetails.email}</span>
            </Typography>
        </CardContent>
        {/* <CardActions>
            <Button size="small" onClick={() => {
                props.delete(consultant.userId.toString());
            }}>Delete</Button>
            <Button size="small" onClick={handleUpdateOpen}>Update</Button>
        </CardActions> */}
        {/* <div>
            <Dialog open={openUpdate} onClose={handleUpdateClose}>
                <AgentUpdate consultantToUpdate={consultant}/>
            </Dialog>
        </div> */}
        </Card>
    );
};

export default ConsultantDisplay;
