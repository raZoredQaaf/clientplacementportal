import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { getBaseApiUrl } from "../../../../config/api-config";
import { Button, Container, Grid } from "@mui/material";
import TextField from '@mui/material/TextField';
import ConsultantDisplay from "./consultant-display/consultant-display.component";


const ConsultantList = () => {
    const [consultants, setConsultants, searchTerm] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        loadConsultants();
    }, []);

    const loadConsultants = () => {
        axios
        .get(getBaseApiUrl()+"consultants")
        .then((response) => {
            console.log(response);
            setConsultants(response.data);
        }).catch((error) => {console.log(error);});
    };

    const searchConsultants = (event) => {
        console.log("Attempting search for : " + event.target.value);
        if (event.target.value.length === 0) {
            loadConsultants();
        } else {
            axios
            .get(getBaseApiUrl()+"consultants/search/"+event.target.value)
            .then((response) => {
                console.log(response);
                setConsultants(response.data);
            }).catch((error) => {
                console.log(error);
                setConsultants([]);
            });
        }
        
    };

    const handleDeleteClicked = (id) => {
        axios.delete(`${getBaseApiUrl()}consultants/${id}`).then(response => loadConsultants());
    };

    return (
        <Container>
        <p></p>
        <TextField id="standard-basic" label="Search" variant="outlined" fullWidth value={searchTerm} onChange={searchConsultants} />
        <p></p>
        <Grid container spacing={2}>
        {consultants.map((consultant) => (
            <>
            <Grid item xs={6}>
                <ConsultantDisplay key={consultant.contactDetails.firstName} consultant={consultant} delete={handleDeleteClicked}/>
            </Grid>
            </>
        ))}
        </Grid>
        
        </Container>
    );
};

export default ConsultantList;
