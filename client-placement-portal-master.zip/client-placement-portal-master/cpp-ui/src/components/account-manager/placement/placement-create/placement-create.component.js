import { Button, Container, TextField } from "@mui/material";
import axios from "axios";
import React, { useNavigate, useState } from "react";
import { getBaseApiUrl } from "../../../../config/api-config";
import './placement-create.style.css';

const PlacementCreate = () => (props) => {

    const { open, handleClose } = props;

    const [jobtitle, setJobTitle] = useState;
    const [jobtitleConflict, setJobTitleConflict] = useState;
    const [jobtitleMessage, setJobTitleMessage] = useState;

    const [jobdescription, setJobDescription] = useState;
    const [jobdescriptionConflict, setJobDescriptionConflict] = useState;
    const [jobdescriptionMessage, setJobDescriptionMessage] = useState;

    const [client, setClient] = useState;
    const [clientConflict, setClientConflict] = useState;
    const [clientMessage, setClientMessage] = useState;

    const [firstName, setFirstName] = useState;
    const [firstNameConflict, setFirstNameConflict] = useState;
    const [firstNameMessage, setFirstNameMessage] = useState;

    const [lastName, setLastName] = useState;
    const [lastNameConflict, setLastNameConflict] = useState;
    const [lastNameMessage, setLastNameMessage] = useState;

    const [email, setEmail] = useState;
    const [emailConflict, setEmailConflict] = useState;
    const [emailMessage, setEmailMessage] = useState;

    const [phone, setPhone] = useState;
    const [phoneConflict, setPhoneConflict] = useState;
    const [phoneMessage, setPhoneMessage] = useState;

    const [contactPerson, setContactPerson] = useState;
    const [contactPersonConflict, setContactPersonConflict] = useState;
    const [ContactPersonMessage, setContactPersonMessage] = useState;

    const [submitConflict, setSubmitConflict] = useState;
    const [submitMessage, setSubmitMessage] = useState;


    const onSubmitHandler = () => {
    setJobTitleConflict(false);
    setJobTitleMessage("");
    setJobDescriptionConflict(false);
    setJobDescriptionMessage("");
    setClientConflict(false);
    setClientMessage("");
    setFirstNameConflict(false);
    setFirstNameMessage("");
    setLastNameConflict(false);
    setLastNameMessage("");
    setEmailConflict(false);
    setEmailMessage("");
    setPhoneConflict(false);
    setPhoneMessage("");
    if (jobtitle.length < 3) {
        setJobTitleConflict(true);
        setJobTitleMessage("Must enter a jobtitle!");
    } else if (jobdescription.length < 5) {
        setJobDescriptionConflict(true);
        setJobDescriptionMessage("Must enter a jobdescription!");
    } else if (client.length < 5) {
        setClientConflict(true);
        setClientMessage("Must enter a client!");
    } else if (contactPerson.length < 3) {
        setContactPersonConflict(true);
        setContactPersonMessage("Must enter a client!");
    } else {
        axios
        .post<Placement>(getBaseApiUrl()+"placements", {
        jobTitle: jobtitle,
        jobDescription: jobdescription,
        client: client,
        contactPerson: {
            firstName: firstName,
            lastName: lastName,
            email: email,
            phone: phone
        }
        })
        .then((response) => ("/Account-Manager/Create-Placement"))
        .catch((error) => {
        console.log("ERROR RESPONSE: ");
        console.log(error);
        setSubmitMessage(error.response.data);
        setSubmitConflict(true);
        });
    }
    };

    return <>
    <Container maxWidth="xl">
        <h1>Create Placement:</h1>
        <form className="form" onSubmit={onSubmitHandler}>
        <div>
            <TextField
                error={jobtitleConflict}
                label="JobTitle:"
                variant="standard"
                type="text"
                value={jobtitle}
                onChange={(event) => setJobTitle(event.target.value)}
                helperText={jobtitleMessage}/>
        </div>
        <div>
            <TextField
                error={jobdescriptionConflict}
                label="JobDescription:"
                variant="standard"
                type="text"
                value={jobdescription}
                onChange={(event) => setClient(event.target.value)}
                helperText={jobdescriptionMessage} />
        </div>
        <div>
            <TextField
                error={clientConflict}
                label="Client:"
                variant="standard"
                type="text"
                value={client}
                onChange={(event) => setClient(event.target.value)}
                helperText={clientMessage} />
        </div>
        <div>
            <TextField
                error={contactPersonConflict}
                label="ContactPerson:"
                variant="standard"
                type="text"
                value={contactPerson}
                onChange={(event) => setClient(event.target.value)}
                helperText={ContactPersonMessage} />
        </div>
        <div>
            <TextField
                error={firstNameConflict}
                label="First Name:"
                variant="standard"
                type="text"
                value={firstName}
                onChange={(event) => setFirstName(event.target.value)}
                helperText={firstNameMessage} />
        </div>
        <div>
            <TextField
                error={lastNameConflict}
                label="Last Name:"
                variant="standard"
                type="text"
                value={lastName}
                onChange={(event) => setLastName(event.target.value)}
                helperText={lastNameMessage} />
        </div>
        <div>
            <TextField
                error={emailConflict}
                label="Email:"
                variant="standard"
                type="text"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                helperText={emailMessage} />
        </div>
        <div>
            <TextField
                error={phoneConflict}
                label="Phone:"
                variant="standard"
                type="text"
                value={phone}
                onChange={(event) => setPhone(event.target.value)}
                helperText={phoneMessage} />
        </div>
        <div>
            <Button onClick={() => {
                onSubmitHandler();
            }}>Submit</Button>
            <Button onClick={() => {
                ("/Account-Manager/Create-Placement");
            }}>Cancel</Button>
        </div>
        </form>
        <div>
            {submitConflict && (
            <span style={{ color: "red" }}>An Placement already exists in that location!</span>
            )}
        </div>
    </Container>
    </>
};


export default PlacementCreate;
