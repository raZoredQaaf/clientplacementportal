import { Button, Card, CardActions, CardContent, Dialog, Typography } from "@mui/material";
import React, { useState } from "react";


const AccountManagerPlacementDisplay = (props) => {

    const {placement, onDelete} = props;

    // declare a new state variable for modal open
    const [openUpdate, setOpenUpdate] = useState(false);

    // function to handle modal open
    const handleUpdateOpen = () => {
        setOpenUpdate(true);
    };

    // function to handle modal close
    const handleUpdateClose = () => {
        setOpenUpdate(false);
    };

    return (
        <Card sx={{ minWidth: 275 }}>
        <CardContent>
            <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
            {placement.client.clientName}
            </Typography>
            <Typography variant="h5" component="div">
            Name: <span className="placement-item">{placement.jobTitle}</span>
            </Typography>
            <Typography sx={{ mb: 1.5 }} color="text.secondary">
            Username: <span className="placement-item">{placement.jobDescription}</span>
            </Typography>
            <Typography variant="body2">
            Email: <span className="placement-item">{placement.client.contactPerson.email}</span>
            </Typography>
        </CardContent>
        <CardActions>
            {/* <Button size="small" onClick={() => {
                props.delete(placement.id.toString());
            }}>Delete</Button>
            <Button size="small" onClick={handleUpdateOpen}>Update</Button> */}
            <Button size="small" onClick={handleUpdateOpen}>View Details</Button>
        </CardActions>
        {/* <div>
            <Dialog open={openUpdate} onClose={handleUpdateClose}>
                <AgentUpdate placementToUpdate={placement}/>
            </Dialog>
        </div> */}
        </Card>
    );
};

export default AccountManagerPlacementDisplay;
