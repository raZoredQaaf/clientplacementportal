import { Button, Container, Grid, TextField } from "@mui/material";
import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getBaseApiUrl } from "../../../../config/api-config";
import AccountManagerPlacementDisplay from "./placement-display/account-manager-placement-display.component";

import './placementStyles.css';

const AccountManagerPlacementList = () => {
  const [placements, setPlacements] = useState([]);
  
  const [searchTerm, setSearchTerm] = useState();
  const navigate = useNavigate();

  useEffect(() => {
    loadPlacements();
  }, []);

  const loadPlacements = () => {
    axios
      .get(getBaseApiUrl() + "placements")
      .then((response) => {
        console.log(response);
        setPlacements(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const searchPlacements = (event) => {
    console.log("Attempting search for : " + event.target.value);
    if (event.target.value.length === 0) {
        loadPlacements();
    } else {
        axios
        .get(getBaseApiUrl()+"placements/search/"+event.target.value)
        .then((response) => {
            console.log(response);
            setPlacements(response.data);
        }).catch((error) => {
            console.log(error);
            setPlacements([]);
        });
    }
    
};

  const handleDeleteClicked = (id) => {
    axios
      .delete(`${getBaseApiUrl()}placements/${id}`)
      .then((response) => loadPlacements());
  };

  return (
    <Container>
      <p></p>
      <div className="topSection">
        <div className="search">
          <TextField id="standard-basic" label="Search" variant="outlined" fullWidth value={searchTerm} onChange={searchPlacements} />
        </div>
        <div className="actions">
          <Button
            variant="contained"
            size="large"
            onClick={() => {
              navigate("/Account-Manager/Create-Placement");
            }}
          >
            Add Placement
          </Button>
        </div>
        
      </div>
      
      <p></p>
      <Grid container spacing={2}>
        {placements.map((placement) => (
          <>
            <Grid item xs={6}>
              <AccountManagerPlacementDisplay
                key={placement.id}
                placement={placement}
                delete={handleDeleteClicked}
              />
            </Grid>
          </>
        ))}
      </Grid>
    </Container>
  );
};

export default AccountManagerPlacementList;
