import React, { useState } from "react";

import { Button, Card, CardActions, CardContent, Container, Dialog, TextField, Typography } from "@mui/material";

import './login.style.css';
import axios from "axios";
import { getBaseApiUrl } from "../../config/api-config";

import cpplogo from '../../images/cpp-logo.png';

import { useAuth } from '../../config/auth';

const LoginPopUp = (props) => {

    const { login, logout } = useAuth();

    const { open, handleClose } = props;

    const [email, setEmail] = useState("");
    const [emailConflict, setEmailConflict] = useState(false);
    const [emailMessage, setEmailMessage] = useState("");

    const [password, setPassword] = useState("");
    const [passwordConflict, setPasswordConflict] = useState(false);
    const [passwordMessage, setPasswordMessage] = useState("");

    const [submitConflict, setSubmitConflict] = useState(false);
    const [submitMessage, setSubmitMessage] = useState("");

    const onSubmitHandler = () => {
        setPasswordMessage("");
        setPasswordConflict(false);
        setEmailMessage("");
        setEmailConflict(false);
        setSubmitMessage("");
        setSubmitConflict(false);
        if (email.length < 3) {
            setEmailConflict(true);
            setEmailMessage("Must enter a username!");
        } else if (password.length < 3) {
            setPasswordConflict(true);
            setPasswordMessage("Must enter a password!");
        } else {
            // Try loggin in consultant
            // if failed try loggin in as account manager
            // if failed return error
            axios
            .get(getBaseApiUrl()+"consultants/login/"+email+"&"+password)
            .then((response) => {
                console.log("RESPONSE LOG: ");
                console.log(response);
                if (response.status === 200) {
                    login(response.data.userId,"consultant");
                } else {
                    setSubmitMessage(response.data.toString());
                            setSubmitConflict(true);
                    
                }
            })
            .catch((error) => {
            console.log("ERROR LOG: ");
            console.log(error);
            // setSubmitMessage(error.response.data);
            // setSubmitConflict(true);
            axios
            .get(getBaseApiUrl()+"account-managers/login/"+email+"&"+password)
            .then((response) => {
                console.log("RESPONSE LOG: ");
                console.log(response);
                if (response.status === 200) {
                    login(response.data.userId, "account-manager");
                } else {
                    setSubmitMessage(response.data.toString());
                    setSubmitConflict(true);
                }
            })
            .catch((error) => {
            console.log("ERROR LOG: ");
            console.log(error);
            setSubmitMessage(error.response.data);
            setSubmitConflict(true);
            });
            });
        }
    };

    return (
        <div>
            <Dialog open={open} onClose={handleClose} fullWidth={ true } maxWidth={"md"}>
                <div className="vertical">
                <Container className="pop-up-card">
                    <div className="spacing">
                    <img src={cpplogo} alt="CPP Logo" height={100} width={300} ></img>
                        <form className="form" onSubmit={onSubmitHandler}>
                        <div>
                            <TextField
                                fullWidth={true}
                                error={emailConflict}
                                label="Email:"
                                variant="standard"
                                type="text"
                                value={email}
                                onChange={(event) => setEmail(event.target.value)}
                                helperText={emailMessage}/>
                        </div>
                        <div className="gap" ></div>
                        <div>
                            <TextField
                                fullWidth={true}
                                error={passwordConflict}
                                label="Password:"
                                variant="standard"
                                type="text"
                                value={password}
                                onChange={(event) => setPassword(event.target.value)}
                                helperText={passwordMessage}/>
                        </div>
                        <div className="gap" ></div>
                        <div>
                            <Button onClick={() => {
                                onSubmitHandler();
                            }}>Login</Button>
                            <Button onClick={() => {
                                props.handleClose();
                            }}>Cancel</Button>
                        </div>
                        </form>
                        <div>
                            {submitConflict && 
                            <h3 style={{ color: "red" }}>{submitMessage}</h3>
                            }
                        </div>
                    </div>
                </Container>
                </div>
            </Dialog>
        </div>
    );
}

export default LoginPopUp;




