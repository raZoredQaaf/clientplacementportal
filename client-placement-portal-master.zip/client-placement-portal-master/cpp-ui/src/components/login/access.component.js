import { Button, Dialog, ThemeProvider, useTheme } from "@mui/material";
import React, { useState } from "react";

import './login.style.css';

import "../../styles/global.style.css";

import LoginPopUp from "./loginPopUp.component";
import SignupPopUp from "./signupPopUp.component";
import { Container } from "@mui/system";

import cpplogo from '../../images/cpp-logo.png';

const Access = () => {

    // declare a new state variable for modal open
    const [openManagerLogin, setOpenManagerLogin] = useState(false);
    const [openAgentLogin, setOpenAgentLogin] = useState(false);

    // function to handle modal open
    const handleManagerOpen = () => {
        setOpenManagerLogin(true);
    };

    // function to handle modal close
    const handleManagerClose = () => {
        setOpenManagerLogin(false);
    };

    // function to handle modal open
    const handleAgentOpen = () => {
        setOpenAgentLogin(true);
    };

    // function to handle modal close
    const handleAgentClose = () => {
        setOpenAgentLogin(false);
    };

    return (
        <div className="loginPage">
            <Container>
            <div className="vertical">
                <img src={cpplogo} alt="CPP Logo" height={200} width={500} ></img>
                <div className="horizontal">
                <Button className="mainButton" variant="contained" color={"primary"} onClick={handleManagerOpen}>
                    Login
                </Button>
                <div className="spacing"></div>
                <Button className="mainButton" variant="contained" color="primary" onClick={handleAgentOpen}>
                    Signup
                </Button>
            </div>
            </div>
            </Container>

            <LoginPopUp open={openManagerLogin} handleClose={handleManagerClose}/>
            <SignupPopUp open={openAgentLogin} handleClose={handleAgentClose} />
        </div>
    );
}

export default Access;