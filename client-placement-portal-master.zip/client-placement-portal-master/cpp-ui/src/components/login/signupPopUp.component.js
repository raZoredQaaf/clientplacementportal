import React, { useState } from "react";

import { Button, Card, CardActions, CardContent, Container, Dialog, FormControlLabel, Switch, TextField, Typography } from "@mui/material";
import { useNavigate } from "react-router-dom";

import cpplogo from '../../images/cpp-logo.png';
import './login.style.css';
import axios from "axios";
import { getBaseApiUrl } from "../../config/api-config";

import { useAuth } from '../../config/auth';

const SignupPopUp = (props) => {

    const { open, handleClose } = props;

    const { login, logout } = useAuth();

    const [email, setEmail] = useState("");
    const [emailConflict, setEmailConflict] = useState(false);
    const [emailMessage, setEmailMessage] = useState("");

    const [firstName, setFirstName] = useState("");
    const [firstNameConflict, setFirstNameConflict] = useState(false);
    const [firstNameMessage, setFirstNameMessage] = useState("");

    const [lastName, setLastName] = useState("");
    const [lastNameConflict, setLastNameConflict] = useState(false);
    const [lastNameMessage, setLastNameMessage] = useState("");

    const [phone, setPhone] = useState("");
    const [phoneConflict, setPhoneConflict] = useState(false);
    const [phoneMessage, setPhoneMessage] = useState("");

    const [password, setPassword] = useState("");
    const [passwordConflict, setPasswordConflict] = useState(false);
    const [passwordMessage, setPasswordMessage] = useState("");

    const [passwordConfirm, setPasswordConfirm] = useState("");
    const [passwordConfirmConflict, setPasswordConfirmConflict] = useState(false);
    const [passwordConfirmMessage, setPasswordConfirmMessage] = useState("");

    const [submitConflict, setSubmitConflict] = useState(false);
    const [submitMessage, setSubmitMessage] = useState("");

    const [accountManager, setAccountManager] = useState(false);
    const [accountManagerConflict, setAccountManagerConflict] = useState(false);
    const [accountManagerMessage, setAccountManagerMessage] = useState("");

    const handleChange = (event) => {
        console.log(accountManager);
        console.log(event);
        if (accountManager === true) {
            setAccountManager(false);
        } else {
            setAccountManager(true);
        }

        console.log(accountManager);
    };

    const navigate = useNavigate();

    const onSubmitHandler = () => {
        setEmailMessage("");
        setEmailConflict(false);

        setFirstNameMessage("");
        setFirstNameConflict(false);

        setLastNameMessage("");
        setLastNameConflict(false);

        setPhoneMessage("");
        setPhoneConflict(false);

        setPasswordMessage("");
        setPasswordConflict(false);

        setPasswordConfirmMessage("");
        setPasswordConfirmConflict(false);

        setSubmitMessage("");
        setSubmitConflict(false);
        if (email.length < 3) {
            setEmailConflict(true);
            setEmailMessage("Must enter an email!");
        } else if (firstName.length < 2) {
            setFirstNameConflict(true);
            setFirstNameMessage("Must Enter a first name!");
        }  else if (lastName.length < 2) {
            setLastNameConflict(true);
            setLastNameMessage("Must Enter a last name!");
        } else if (phone.length < 2) {
            setPhoneConflict(true);
            setPhoneMessage("Must Enter a last name!");
        } 
        else if (password.length < 3) {
            setPasswordConflict(true);
            setPasswordMessage("Must enter a password!");
        } else if (passwordConfirm.length < 3) {
            setPasswordConfirmConflict(true);
            setPasswordConfirmMessage("Must enter a password confirmation!");
        } else if (passwordConfirm !== password ) {
            setPasswordConfirmConflict(true);
            setPasswordConfirmMessage("Passwords do not match!");
        } else {

            if (accountManager === true) {
                axios
                .post(getBaseApiUrl()+"account-managers", {
                email: email.toLowerCase(),
                password: password,
                contactDetails: {
                    firstName: firstName.toLowerCase(),
                    lastName: lastName.toLowerCase(),
                    email: email.toLowerCase(),
                    phone: phone
                }
                })
                .then((response) => {
                    login(response.data.userId, "account-manager");
                })
                .catch((error) => {
                console.log("ERROR RESPONSE: ");
                console.log(error);
                setSubmitMessage(error.response.data);
                setSubmitConflict(true);
                });
            } else {
                axios
                .post(getBaseApiUrl()+"consultants", {
                email: email.toLowerCase(),
                password: password,
                contactDetails: {
                    firstName: firstName.toLowerCase(),
                    lastName: lastName.toLowerCase(),
                    email: email.toLowerCase(),
                    phone: phone
                }
                })
                .then((response) => {
                    login(response.data.userId, "consultant");
                })
                .catch((error) => {
                console.log("ERROR RESPONSE: ");
                console.log(error);
                setSubmitMessage(error.response.data);
                setSubmitConflict(true);
                });
            }
            
        }
    };

    return (
        <div>
            <Dialog open={open} onClose={handleClose} fullWidth={ true } maxWidth={"md"}>
            <div className="vertical">
                <Container className="pop-up-card">
                <div className="spacing">
                    <img src={cpplogo} alt="CPP Logo" height={100} width={300} ></img>
                        <form className="form" onSubmit={onSubmitHandler}>
                        <div>
                            <TextField
                                fullWidth={true}
                                error={firstNameConflict}
                                label="First Name:"
                                variant="standard"
                                type="text"
                                value={firstName}
                                onChange={(event) => setFirstName(event.target.value)}
                                helperText={firstNameMessage}/>
                        </div>
                        <div className="gap" ></div>
                        <div>
                            <TextField
                                fullWidth={true}
                                error={lastNameConflict}
                                label="Last Name:"
                                variant="standard"
                                type="text"
                                value={lastName}
                                onChange={(event) => setLastName(event.target.value)}
                                helperText={lastNameMessage}/>
                        </div>
                        <div className="gap" ></div>
                        <div>
                            <TextField
                                fullWidth={true}
                                error={emailConflict}
                                label="Email:"
                                variant="standard"
                                type="text"
                                value={email}
                                onChange={(event) => setEmail(event.target.value)}
                                helperText={emailMessage}/>
                        </div>
                        <div className="gap" ></div>
                        <div>
                            <TextField
                                fullWidth={true}
                                error={phoneConflict}
                                label="Phone:"
                                variant="standard"
                                type="text"
                                value={phone}
                                onChange={(event) => setPhone(event.target.value)}
                                helperText={phoneMessage}/>
                        </div>
                        <div className="gap" ></div>
                        <div>
                            <TextField
                                fullWidth={true}
                                error={passwordConflict}
                                label="Password:"
                                variant="standard"
                                type="text"
                                value={password}
                                onChange={(event) => setPassword(event.target.value)}
                                helperText={passwordMessage}/>
                        </div>
                        <div className="gap" ></div>
                        <div>
                            <TextField
                                fullWidth={true}
                                error={passwordConfirmConflict}
                                label="Confirm Password:"
                                variant="standard"
                                type="text"
                                value={passwordConfirm}
                                onChange={(event) => setPasswordConfirm(event.target.value)}
                                helperText={passwordConfirmMessage}/>
                        </div>
                        <div className="gap" ></div>
                        <div>
                        <FormControlLabel control={<Switch
                            checked={accountManager}
                            onChange={handleChange}
                            inputProps={{ 'aria-label': 'controlled' }}
                            />} label="Select this if you would like to sign up as an account manager" />
                        </div>
                        <div>
                            <Button onClick={() => {
                                onSubmitHandler();
                            }}>Signup</Button>
                            <Button onClick={() => {
                                props.handleClose();
                            }}>Cancel</Button>
                        </div>
                        </form>
                        <div>
                            {submitConflict && 
                            <h3 style={{ color: "red" }}>{submitMessage}</h3>
                            }
                        </div>
                    </div>
                </Container>
                </div>
            </Dialog>
        </div>
    );
}

export default SignupPopUp;




