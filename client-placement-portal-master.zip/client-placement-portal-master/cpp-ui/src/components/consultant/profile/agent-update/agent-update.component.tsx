import React, { useState, FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { getBaseApiUrl } from "../../../../config/api-config";
import { Box, Container, Button, TextField } from "@mui/material";
import Agent from "../../../../models/consultant.model";
import './agent-update.style.css';

interface UpdateAgentProps {
    agentToUpdate: Agent;
}

const AgentUpdate = (props: UpdateAgentProps) => {

    const [username, setUsername] = useState<string>(props.agentToUpdate.username);
    const [usernameConflict, setUsernameConflict] = useState<boolean>(false);
    const [usernameMessage, setUsernameMessage] = useState<string>("");

    const [firstName, setFirstName] = useState<string>(props.agentToUpdate.contactDetails.firstName);
    const [firstNameConflict, setFirstNameConflict] = useState<boolean>(false);
    const [firstNameMessage, setFirstNameMessage] = useState<string>("");

    const [lastName, setLastName] = useState<string>(props.agentToUpdate.contactDetails.lastName);
    const [lastNameConflict, setLastNameConflict] = useState<boolean>(false);
    const [lastNameMessage, setLastNameMessage] = useState<string>("");

    const [email, setEmail] = useState<string>(props.agentToUpdate.contactDetails.email);
    const [emailConflict, setEmailConflict] = useState<boolean>(false);
    const [emailMessage, setEmailMessage] = useState<string>("");

    const [phone, setPhone] = useState<string>(props.agentToUpdate.contactDetails.phone);
    const [phoneConflict, setPhoneConflict] = useState<boolean>(false);
    const [phoneMessage, setPhoneMessage] = useState<string>("");

    const [submitConflict, setSubmitConflict] = useState<boolean>(false);
    const [submitMessage, setSubmitMessage] = useState<string>("");

    const navigate = useNavigate();

    const onSubmitHandler = () => {
    setUsernameConflict(false);
    setUsernameMessage("");
    setFirstNameConflict(false);
    setFirstNameMessage("");
    setLastNameConflict(false);
    setLastNameMessage("");
    setEmailConflict(false);
    setEmailMessage("");
    setPhoneConflict(false);
    setPhoneMessage("");
    if (username.length < 3) {
        setUsernameConflict(true);
        setUsernameMessage("Must enter a username!");
    } else {
        axios
        .post<Agent>(getBaseApiUrl()+"agents", {
            userId: props.agentToUpdate.userId,
            username: username,
            password: props.agentToUpdate.password,
            contactDetails: {
                contactId : props.agentToUpdate.contactDetails.contactId,
                firstName: firstName,
                lastName: lastName,
                email: email,
                phone: phone
            }
        })
        .then((response) => {
            window.location.reload();
            // navigate("/Manager/Agents");
        })
        .catch((error) => {
        console.log("ERROR RESPONSE: ");
        console.log(error);
        setSubmitMessage(error.response.data);
        setSubmitConflict(true);
        });
    }
    };

    return <>
    <Container>
        <h1>Update Agent:</h1>
        <form className="form" onSubmit={onSubmitHandler}>
        <div>
            <TextField
                error={usernameConflict}
                label="Username:"
                variant="standard"
                type="text"
                value={username}
                onChange={(event) => setUsername(event.target.value)}
                helperText={usernameMessage}/>
        </div>
        <div>
            <TextField
                error={firstNameConflict}
                label="First Name:"
                variant="standard"
                type="text"
                value={firstName}
                onChange={(event) => setFirstName(event.target.value)}
                helperText={firstNameMessage} />
        </div>
        <div>
            <TextField
                error={lastNameConflict}
                label="Last Name:"
                variant="standard"
                type="text"
                value={lastName}
                onChange={(event) => setLastName(event.target.value)}
                helperText={lastNameMessage} />
        </div>
        <div>
            <TextField
                error={emailConflict}
                label="Email:"
                variant="standard"
                type="text"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                helperText={emailMessage} />
        </div>
        <div>
            <TextField
                error={phoneConflict}
                label="Phone:"
                variant="standard"
                type="text"
                value={phone}
                onChange={(event) => setPhone(event.target.value)}
                helperText={phoneMessage} />
        </div>
        <div>
            <Button onClick={() => {
                onSubmitHandler();
            }}>Submit</Button>
            <Button onClick={() => {
                window.location.reload();
            }}>Cancel</Button>
        </div>
        </form>
        <div>
            {submitConflict && (
            <span style={{ color: "red" }}>An agent already exists in that location!</span>
            )}
        </div>
    </Container>
    </>
};


export default AgentUpdate;
