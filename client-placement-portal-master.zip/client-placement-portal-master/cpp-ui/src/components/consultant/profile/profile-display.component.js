import { Button, Card, CardActions, CardContent, Container, Dialog, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import { Navigate , useNavigate} from "react-router-dom";
import axios from "axios";
import { getBaseApiUrl } from "../../../config/api-config";
import { useAuth } from "../../../config/auth";

const ProfileDisplay = () => {
    const { userId } = useAuth();

    const [consultant, setConsultant] = useState([]);

    const navigate = useNavigate();

    useEffect(() => {
        loadConsultant(userId);
    }, [userId]);

    const loadConsultant = (consultantId) => {
        axios
        .get(getBaseApiUrl() + "consultants/" + consultantId )
        .then((response) => {
            console.log(response);
            setConsultant(response.data);
        })
        .catch((error) => {
            console.log(error);
        });
    };

    const [openUpdate, setOpenUpdate] = useState(false);

    const handleUpdateOpen = () => {
        setOpenUpdate(true);
    };

    const handleUpdateClose = () => {
        setOpenUpdate(false);
    };

    return(
        <Container>
        <h1>Consultant Profile</h1>
        <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
            {consultant.email}
            </Typography>
        </Container>
    );
};

export default ProfileDisplay;