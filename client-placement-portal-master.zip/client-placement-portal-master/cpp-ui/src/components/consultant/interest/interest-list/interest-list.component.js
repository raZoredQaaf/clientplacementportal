import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { getBaseApiUrl } from "../../../../config/api-config";
import { Button, Container, Grid } from "@mui/material";
import InterestDisplay from "./interest-display/interest-display.component";

const InterestList = () => {
    const [interests, setInterests] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        loadInterests();
    }, []);

    const loadInterests = () => {
        axios
        .get(getBaseApiUrl()+"interests")
        .then((response) => {
            console.log(response);
            setInterests(response.data);
        }).catch((error) => {console.log(error);});
    };

    const handleDeleteClicked = (id) => {
        axios.delete(`${getBaseApiUrl()}interests/${id}`).then(response => loadInterests());
    };

    return (
        <Container>
        <h1>All Interests:</h1>
        <p></p>
        <Grid container spacing={2}>
        {interests.map((interest) => (
            <>
            <Grid item xs={6}>
                <InterestDisplay key={interest.placement.client.clientName} interest={interest} delete={handleDeleteClicked}/>
            </Grid>
            </>
        ))}
        </Grid>
        
        </Container>
    );
};

export default InterestList;
