import { Button, Card, CardActions, CardContent, Dialog, Typography } from "@mui/material";
import React, { useState } from "react";


const InterestDisplay = (props) => {

    const {interest, onDelete} = props;

    // declare a new state variable for modal open
    const [openUpdate, setOpenUpdate] = useState(false);

    // function to handle modal open
    const handleUpdateOpen = () => {
        setOpenUpdate(true);
    };

    // function to handle modal close
    const handleUpdateClose = () => {
        setOpenUpdate(false);
    };

    return (
        <Card sx={{ minWidth: 275 }}>
        <CardContent>
            <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
            {interest.placement.client.clientName}
            </Typography>
            <Typography variant="h5" component="div">
            <span className="interest-item">{interest.placement.jobTitle}</span>
            </Typography>
            <Typography sx={{ mb: 1.5 }} color="text.secondary">
            <span className="interest-item">{interest.placement.jobDescription}</span>
            </Typography>
            <Typography variant="body2">
            Status: <span className="interest-item">{interest.status}</span>
            </Typography>
        </CardContent>
        <CardActions>
            <Button size="small" onClick={() => {
                props.delete(interest.userId.toString());
            }}>Delete</Button>
            <Button size="small" onClick={handleUpdateOpen}>Update</Button>
        </CardActions>
        {/* <div>
            <Dialog open={openUpdate} onClose={handleUpdateClose}>
                <AgentUpdate interestToUpdate={interest}/>
            </Dialog>
        </div> */}
        </Card>
    );
};

export default InterestDisplay;
