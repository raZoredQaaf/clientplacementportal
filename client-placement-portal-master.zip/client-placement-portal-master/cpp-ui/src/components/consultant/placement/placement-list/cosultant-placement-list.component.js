import { Button, Container, Grid } from "@mui/material";
import axios from "axios";
import React, { useEffect, useState } from "react";
import { getBaseApiUrl } from "../../../../config/api-config";
import ConsultantPlacementDisplay from "./placement-display/conusltant-placement-display.component";

const ConsultantPlacementList = () => {
  const [placements, setPlacements] = useState([]);

  useEffect(() => {
    loadPlacements();
  }, []);

  const loadPlacements = () => {
    axios
      .get(getBaseApiUrl() + "placements")
      .then((response) => {
        console.log(response);
        setPlacements(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <Container>
      <h1>All Placements:</h1>
      <p></p>
      <Grid container spacing={2}>
        {placements.map((placement) => (
          <>
            <Grid item xs={6}>
              <ConsultantPlacementDisplay
                key={placement.id}
                placement={placement}
              />
            </Grid>
          </>
        ))}
      </Grid>
    </Container>
  );
};

export default ConsultantPlacementList;
