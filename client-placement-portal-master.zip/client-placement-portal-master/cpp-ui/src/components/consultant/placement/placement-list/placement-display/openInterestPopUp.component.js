import React, { useState } from "react";

import { Button, Container, Dialog, TextField } from "@mui/material";

import './interest.style.css';
import axios from "axios";
import { getBaseApiUrl } from "../../../../../config/api-config";

const InterestPopUp = (props) => {

    const { open, consultant, placement, handleClose } = props;

    const [reason, setReason] = useState("");
    const [reasonConflict, setReasonConflict] = useState(false);
    const [reasonMessage, setReasonMessage] = useState("");

    const [submitConflict, setSubmitConflict] = useState(false);
    const [submitMessage, setSubmitMessage] = useState("");

    const onSubmitHandler = () => {
        setReasonMessage("");
        setReasonConflict(false);
        setSubmitMessage("");
        setSubmitConflict(false);
        if (reason.length < 10) {
            setReasonConflict(true);
            setReasonMessage("Must enter a reason as to why you want the role!");
        } else {
            axios
            .post(getBaseApiUrl()+"interests", {
            consultant: consultant,
            placement: placement,
            status:"Interested",
            reason: reason
            })
            .then((response) => {
                setSubmitMessage("Success, you have registered your interest for this placement");
            })
            .catch((error) => {
                console.log("ERROR RESPONSE: ");
                console.log(error);
                setSubmitMessage(error.response.data);
                setSubmitConflict(true);
            });
        }
    };

    return (
        <div>
            <Dialog open={open} onClose={handleClose} fullWidth={ true } maxWidth={"md"}>
                <div className="vertical">
                <Container className="pop-up-card">
                    <div className="spacing">
                        <div>
                            <TextField
                                fullWidth={true}
                                error={reasonConflict}
                                label="Reason:"
                                variant="standard"
                                type="text" 
                                value={reason}
                                onChange={(event) => setReason(event.target.value)}
                                helperText={reasonMessage}/>
                        </div>
                        <div className="gap" ></div>
                    </div>
                    <div>
                        <Button onClick={() => {
                            onSubmitHandler();
                        }}>Submit</Button>
                        <Button onClick={() => {
                            props.handleClose();
                        }}>Cancel</Button>
                    </div>
                    <div>
                        {submitConflict && 
                        <h3 style={{ color: "red" }}>{submitMessage}</h3>
                        }
                    </div>
                </Container>
                </div>
            </Dialog>
        </div>
    );
}

export default InterestPopUp;