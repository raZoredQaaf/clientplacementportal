import { Button, Card, CardActions, CardContent, Dialog, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import { Navigate , useNavigate} from "react-router-dom";
import axios from "axios";
import { getBaseApiUrl } from "../../../../../config/api-config";
import { useAuth } from "../../../../../config/auth";

import InterestPopUp from "./openInterestPopUp.component";

const ConsultantPlacementDisplay = (props) => {

    const {placement} = props;
    const { userId } = useAuth();
    const [consultant, setConsultant] = useState([]);
    const [openInterestPopUp, setOpenInterestPopUp] = useState(false);
    
    // function to handle modal close
    const handleInterestClose = () => {
        setOpenInterestPopUp(false);
    };

    // function to handle modal open
    const handleInterestOpen = () => {
        setOpenInterestPopUp(true);
    };

    const navigate = useNavigate();

    useEffect(() => {
        loadConsultant(userId);
    }, [userId]);

    const loadConsultant = (consultantId) => {
        axios
        .get(getBaseApiUrl() + "consultants/" + consultantId )
        .then((response) => {
            console.log(response);
            setConsultant(response.data);
        })
        .catch((error) => {
            console.log(error);
        });
    };

    // // function to handle modal open
    // const handleRegisterInterestClick = () => {
    //     // send the data to the add interest api.
    //     // on success or error show the pop up window
    //     
    // };


    return (
        <Card sx={{ minWidth: 275 }}>
        <CardContent>
            <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
            {placement.client.clientName}
            </Typography>
            <Typography variant="h5" component="div">
            Job Title: <span className="placement-item">{placement.jobTitle}</span>
            </Typography>
            <Typography sx={{ mb: 1.5 }} color="text.secondary">
            Job Description: <span className="placement-item">{placement.jobDescription}</span>
            </Typography>
            <Typography variant="body2">
            Contact Person: <span className="placement-item">{placement.client.contactPerson.firstName + " " + placement.client.contactPerson.lastName}</span>
            </Typography>
        </CardContent>
        <CardActions>
            <Button size="small" onClick={handleInterestOpen}>Register Interest</Button>
        </CardActions>
        <InterestPopUp open={openInterestPopUp} consultant={consultant} placement={placement} handleClose={handleInterestClose}/>
        </Card>
    );
};

export default ConsultantPlacementDisplay;
