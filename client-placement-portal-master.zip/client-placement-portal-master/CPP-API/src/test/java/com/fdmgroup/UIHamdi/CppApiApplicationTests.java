package com.fdmgroup.UIHamdi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CppApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
