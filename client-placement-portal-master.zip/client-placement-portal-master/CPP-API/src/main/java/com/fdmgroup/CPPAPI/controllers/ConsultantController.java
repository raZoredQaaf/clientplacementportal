package com.fdmgroup.cppapi.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fdmgroup.cppapi.exceptions.ConsultantNotFoundException;
import com.fdmgroup.cppapi.exceptions.InvalidPasswordException;
import com.fdmgroup.cppapi.models.Consultant;
import com.fdmgroup.cppapi.services.ConsultantServiceImp;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/api/v1/consultants")
public class ConsultantController {
	private ConsultantServiceImp consultantService;
	
	public ConsultantController(ConsultantServiceImp consultantService) {
		this.consultantService = consultantService;
	}
	
	@Operation(summary = "Create a new consultant")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "201", description = "Consultant created successfully", headers = {
			@Header(name = "location", description = "Uri to access to create consultant")
		}, content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)
		})
	})
	@CrossOrigin(origins = "http://localhost:3000")
	@PostMapping
	public ResponseEntity<?> addConsultant(@Valid @RequestBody Consultant consultant, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			Map<String, String> errors = new HashMap<>();
			for (FieldError error : bindingResult.getFieldErrors()) {
				errors.put(error.getField(), error.getDefaultMessage());
			}
			return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(this.consultantService.addConsultant(consultant), HttpStatus.CREATED);
	}

	@Operation(summary = "Search All Consultants")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Find all consultants successfully", headers = {
			@Header(name = "location", description = "Uri to access to find all consultants")
		}, content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)
		})
	})
	@CrossOrigin(origins = "http://localhost:3000")
	
	@GetMapping("/search/{query}")
	public ResponseEntity<?> searchAllConsultants(@PathVariable String query) {
		// return new ResponseEntity<>(this.consultantService.getAllConsultants(), HttpStatus.OK);
		List<Consultant> foundConsultants = new ArrayList<Consultant>();
		String lowercaseQuery = query.toLowerCase();
		Iterable<Consultant> emailSearchResults = this.consultantService.searchConsultantByEmail(lowercaseQuery);
		Iterable<Consultant> firstNameSearchResults = this.consultantService.searchConsultantByFirstName(lowercaseQuery);
		Iterable<Consultant> lastNameSearchResults = this.consultantService.searchConsultantByLastName(lowercaseQuery);
		emailSearchResults.forEach(foundConsultants::add);
		firstNameSearchResults.forEach(foundConsultants::add);
		lastNameSearchResults.forEach(foundConsultants::add);
		List<Consultant> listWithoutDuplicates = new ArrayList<>(new HashSet<Consultant>(foundConsultants));
		if (listWithoutDuplicates.size() < 1) {
			return new ResponseEntity<>(
					new ConsultantNotFoundException(query).getMessage(),
					HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(listWithoutDuplicates, HttpStatus.OK);
	}

	@Operation(summary = "Find All Consultants")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Find all consultants successfully", headers = {
			@Header(name = "location", description = "Uri to access to find all consultants")
		}, content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)
		})
	})
	@CrossOrigin(origins = "http://localhost:3000")
	@GetMapping
	public ResponseEntity<?> getAllConsultants() {
		return new ResponseEntity<>(this.consultantService.getAllConsultants(), HttpStatus.OK);
	}

	@Operation(summary = "Update an Consultant")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Consultant updated successfully", headers = {
			@Header(name = "location", description = "Uri to access to update consultant")
		}, content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)
		})
	})
	@CrossOrigin(origins = "http://localhost:3000")
	@PutMapping
	public ResponseEntity<?> updateConsultant(@RequestBody Consultant consultant) {
		return new ResponseEntity<>(this.consultantService.updateConsultant(consultant), HttpStatus.OK);
	}

	@Operation(summary = "Find consultant by id")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "find an consultant successfully", headers = {
			@Header(name = "location", description = "Uri to access to find consultant")
		}, content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)
		})
	})
	@CrossOrigin(origins = "http://localhost:3000")
	@GetMapping("/{id}")
	public ResponseEntity<?> findConsultantById(@PathVariable Long id) {
		Consultant consultant = this.consultantService.findConsultantById(id);
		if (consultant == null) {
			return new ResponseEntity<>(
					new ConsultantNotFoundException(id.toString()).getMessage(),
					HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(consultant, HttpStatus.OK);
	}

	@CrossOrigin(origins = "http://localhost:3000")
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteConsultantById(@PathVariable Long id) {
		Consultant consultant = this.consultantService.findConsultantById(id);
		if (consultant == null) {
			return new ResponseEntity<>(
					new ConsultantNotFoundException(id.toString()).getMessage(),
					HttpStatus.NOT_FOUND);
		}
		this.consultantService.deleteConsultantById(id);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@Operation(summary = "Login consultant by email and password")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Logged In Consultant Successfully", headers = {
			@Header(name = "location", description = "Uri to login an consultant")
		}, content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)
		})
	})
	@CrossOrigin(origins = "http://localhost:3000")
	@GetMapping("/login/{email}&{password}")
	public ResponseEntity<?> loginConsultant(@PathVariable String email, @PathVariable String password) {
		Consultant consultant = this.consultantService.findConsultantByEmail(email);
		if (consultant == null) {
			return new ResponseEntity<>(
					new ConsultantNotFoundException(email).getMessage(),
					HttpStatus.NOT_FOUND);
		} else {
			if (consultant.getPassword().compareTo(password) == 0) {
				return new ResponseEntity<>(consultant, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(
					new InvalidPasswordException(password).getMessage(),
					HttpStatus.FORBIDDEN);
			}
		}
	}
}
