package com.fdmgroup.cppapi.models;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import org.hibernate.annotations.Fetch;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Placement {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "placement_gen")
	@SequenceGenerator(name = "placement_gen", sequenceName = "placement_seq", allocationSize = 1)
    private Long id;

    private String jobTitle;

    private String jobDescription; 

    @OneToOne(cascade = CascadeType.ALL)
    private Client client;

    @OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name="placement_streams", joinColumns=@JoinColumn(name="placement_id"), inverseJoinColumns=@JoinColumn(name="stream_id"))
    private List<Stream> desiredStreams;

    @OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name="placement_interests", joinColumns=@JoinColumn(name="placement_id"), inverseJoinColumns=@JoinColumn(name="interest_id"))
    @JsonIgnore
    private List<Interest> applicants;

    public Placement () {}

    public Placement(String jobTitle, String jobDescription, Client client, List<Stream> desiredStreams,
            List<Interest> applicants) {
        this.jobTitle = jobTitle;
        this.jobDescription = jobDescription;
        this.client = client;
        this.desiredStreams = desiredStreams;
        this.applicants = applicants;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    public List<Stream> getDesiredStreams() {
        return desiredStreams;
    }

    public void setDesiredStreams(List<Stream> desiredStream) {
        this.desiredStreams = desiredStreams;
    }

    public List<Interest> getApplicants() {
        return applicants;
    }

    public void setApplicants(List<Interest> applicants) {
        this.applicants = applicants;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }
    
    
    }
