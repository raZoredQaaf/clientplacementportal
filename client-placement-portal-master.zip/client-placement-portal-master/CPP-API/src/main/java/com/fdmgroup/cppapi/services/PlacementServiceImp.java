package com.fdmgroup.cppapi.services;

import org.springframework.stereotype.Service;

import com.fdmgroup.cppapi.models.Placement;
import com.fdmgroup.cppapi.repositories.PlacementRepository;

@Service
public class PlacementServiceImp implements PlacementService {
    
    private PlacementRepository placementsRepository;
	
	public PlacementServiceImp(PlacementRepository placementsRepository) {
		this.placementsRepository = placementsRepository;
	}

    @Override
	public Placement findPlacementsById(Long id) {
		return this.placementsRepository.findById(id).orElse(null);
    }

	@Override
	public Placement savePlacements(Placement placements) {
		return this.placementsRepository.save(placements);
	}

	@Override
	public Placement updatePlacements(Placement placements) {
		return this.placementsRepository.save(placements);
	}

	@Override
	public void deletePlacementsById(Long id) {
		this.placementsRepository.deleteById(id);

	

	}

	@Override
	public Iterable<Placement> getAllPlacements() {
		return this.placementsRepository.findAll();
	}

	
}