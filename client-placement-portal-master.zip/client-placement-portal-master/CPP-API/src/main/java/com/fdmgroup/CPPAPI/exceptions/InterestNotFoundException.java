package com.fdmgroup.cppapi.exceptions;

public class InterestNotFoundException extends RuntimeException {

    public InterestNotFoundException(String id) {
        super("Could not find agent: " + id);
    }
}