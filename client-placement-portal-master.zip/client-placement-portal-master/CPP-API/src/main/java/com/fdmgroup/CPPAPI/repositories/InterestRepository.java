package com.fdmgroup.cppapi.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fdmgroup.cppapi.models.Interest;

@Repository
public interface InterestRepository extends JpaRepository<Interest, Long>{
	@Query("select interest from Interest interest where interest.consultant.id = ?1")
    public Iterable<Interest> findAllByConsultantId(long id);
	@Query("select interest from Interest interest where interest.placement.id = ?1")
	public Iterable<Interest> findAllByPlacementId(long id);
	
}
