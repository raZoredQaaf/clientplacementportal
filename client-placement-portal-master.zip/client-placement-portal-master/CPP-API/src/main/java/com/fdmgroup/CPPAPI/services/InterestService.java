package com.fdmgroup.cppapi.services;

import com.fdmgroup.cppapi.models.Interest;

public interface InterestService {
	
	Interest addInterest(Interest interest);
	
	Interest updateInterest(Interest interest);

	void deleteInterestById(Long id);

    Iterable<Interest> getAllInterests();

    Interest findInterestById(Long id);
    
    Iterable<Interest> findAllByPlacementId(Long id);
    
    Iterable<Interest> findAllByConsultantId(Long id);
    

}
