package com.fdmgroup.cppapi.services;

import com.fdmgroup.cppapi.models.Consultant;

public interface ConsultantService {
	
	Consultant findConsultantByEmail(String email);
	
	Consultant addConsultant(Consultant consultant);
	
	Consultant updateConsultant(Consultant consultant);

	void deleteConsultantById(Long id);

    Iterable<Consultant> getAllConsultants();

    Consultant findConsultantById(Long id);
    
    Iterable<Consultant> searchConsultantByEmail(String email);

	Iterable<Consultant> searchConsultantByFirstName(String firstName);

	Iterable<Consultant> searchConsultantByLastName(String lastName);
}
