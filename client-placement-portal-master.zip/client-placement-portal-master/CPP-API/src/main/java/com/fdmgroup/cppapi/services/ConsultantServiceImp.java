package com.fdmgroup.cppapi.services;

import org.springframework.stereotype.Service;

import com.fdmgroup.cppapi.models.Consultant;
import com.fdmgroup.cppapi.repositories.ConsultantRepository;

@Service
public class ConsultantServiceImp implements ConsultantService {
	
	private ConsultantRepository consultantRepository;

	
	public ConsultantServiceImp(ConsultantRepository consultantRepository) {
		this.consultantRepository = consultantRepository;
	}
	
	@Override
	public Consultant findConsultantByEmail(String email) {
		return this.consultantRepository.findByEmail(email).orElse(null);
	}


	@Override
    public Consultant addConsultant(Consultant consultant) {
        // No id provided so will perform insert statement
        return this.consultantRepository.save(consultant);
    }

    @Override
    public Consultant updateConsultant(Consultant consultant) {
        // Id provided so will perform update statement
        return this.consultantRepository.save(consultant);
    }

    @Override
    public void deleteConsultantById(Long id) {
        this.consultantRepository.deleteById(id);
    }

    @Override
    public Iterable<Consultant> getAllConsultants() {
        return this.consultantRepository.findAll();
    }

    @Override
    public Consultant findConsultantById(Long id) {
        return this.consultantRepository.findById(id).orElse(null);
    }

    @Override
    public Iterable<Consultant> searchConsultantByEmail(String email) {
        return this.consultantRepository.searchByEmail(email);
    }

    @Override
    public Iterable<Consultant> searchConsultantByFirstName(String firstName) {
        return this.consultantRepository.searchByFirstName(firstName);
    }

    @Override
    public Iterable<Consultant> searchConsultantByLastName(String lastName) {
        return this.consultantRepository.searchByLastName(lastName);
    }
}
