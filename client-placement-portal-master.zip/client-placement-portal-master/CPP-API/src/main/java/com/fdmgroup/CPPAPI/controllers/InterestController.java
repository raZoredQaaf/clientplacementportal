package com.fdmgroup.cppapi.controllers;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fdmgroup.cppapi.services.InterestServiceImp;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.util.HashMap;
import java.util.Map;
import javax.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.fdmgroup.cppapi.exceptions.InterestExistsException;
import com.fdmgroup.cppapi.exceptions.InterestNotFoundException;
import com.fdmgroup.cppapi.models.Interest;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;


@RestController
@RequestMapping("/api/v1/interests")
public class InterestController {
	private InterestServiceImp interestService;

	public InterestController(InterestServiceImp interestService) {
		this.interestService = interestService;
	}

	@Operation(summary = "Create a new interest")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "201", description = "Interest created successfully", headers = {
			@Header(name = "location", description = "Uri to access to create interest")
		}, content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)
		})
	})
	@CrossOrigin(origins = "http://localhost:3000")
	@PostMapping
	public ResponseEntity<?> addInterest(@Valid @RequestBody Interest interest, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			Map<String, String> errors = new HashMap<>();
			for (FieldError error : bindingResult.getFieldErrors()) {
				errors.put(error.getField(), error.getDefaultMessage());
			}
			return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
		}
		Iterable<Interest> preExisitingInterests = this.interestService.findAllByConsultantId(interest.getConsultant().getUserId());
		Boolean alreadyExists = false;
		for (Interest preExistingInterest: preExisitingInterests) {
			if (preExistingInterest.getPlacement().getId() == interest.getPlacement().getId()) {
				alreadyExists = true;
			}
		}
		if (alreadyExists) {
			return new ResponseEntity<>(
				new InterestExistsException(interest.getConsultant().getUserId().toString()).getMessage(),
				HttpStatus.NOT_FOUND);
		} else {
		return new ResponseEntity<>(this.interestService.addInterest(interest), HttpStatus.CREATED);
		}
	}

	@Operation(summary = "Find All Interests")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Find all interests successfully", headers = {
			@Header(name = "location", description = "Uri to access to find all interests")
		}, content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)
		})
	})
	@CrossOrigin(origins = "http://localhost:3000")
	@GetMapping
	public ResponseEntity<?> getAllInterests() {
		return new ResponseEntity<>(this.interestService.getAllInterests(), HttpStatus.OK);
	}
	
	@Operation(summary = "Find All Interests with consultant Id")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Find all interests with consultant Id successfully", headers = {
			@Header(name = "location", description = "Uri to access to find all interests with consultant Id")
		}, content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)
		})
	})
	@CrossOrigin(origins = "http://localhost:3000")
	@GetMapping("/consultant/{id}")
	public ResponseEntity<?> getAllInterestsByConsultantId(@PathVariable Long id) {
		return new ResponseEntity<>(this.interestService.findAllByConsultantId(id), HttpStatus.OK);
	}
	
	@Operation(summary = "Find All Interests with placement Id")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Find all interests with placement Id successfully", headers = {
			@Header(name = "location", description = "Uri to access to find all interests with placement Id")
		}, content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)
		})
	})
	@CrossOrigin(origins = "http://localhost:3000")
	@GetMapping("/placement/{id}")
	public ResponseEntity<?> getAllInterestsByPlacementId(@PathVariable Long id) {
		return new ResponseEntity<>(this.interestService.findAllByPlacementId(id), HttpStatus.OK);
	}

	@Operation(summary = "Update an Interest")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Interest updated successfully", headers = {
			@Header(name = "location", description = "Uri to access to update interest")
		}, content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)
		})
	})
	@CrossOrigin(origins = "http://localhost:3000")
	@PutMapping
	public ResponseEntity<?> updateInterest(@RequestBody Interest interest) {
		return new ResponseEntity<>(this.interestService.updateInterest(interest), HttpStatus.OK);
	}

	@Operation(summary = "Find interest by id")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "find an interest successfully", headers = {
			@Header(name = "location", description = "Uri to access to find interest")
		}, content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)
		})
	})
	@CrossOrigin(origins = "http://localhost:3000")
	@GetMapping("/{id}")
	public ResponseEntity<?> findInterestById(@PathVariable Long id) {
		Interest interest = this.interestService.findInterestById(id);
		if (interest == null) {
			return new ResponseEntity<>(
					new InterestNotFoundException(id.toString()).getMessage(),
					HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(interest, HttpStatus.OK);
	}

	@CrossOrigin(origins = "http://localhost:3000")
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteInterestById(@PathVariable Long id) {
		Interest interest = this.interestService.findInterestById(id);
		if (interest == null) {
			return new ResponseEntity<>(
					new InterestNotFoundException(id.toString()).getMessage(),
					HttpStatus.NOT_FOUND);
		}
		this.interestService.deleteInterestById(id);
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
