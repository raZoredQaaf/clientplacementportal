package com.fdmgroup.cppapi.config;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fdmgroup.cppapi.models.AccountManager;
import com.fdmgroup.cppapi.models.Address;
import com.fdmgroup.cppapi.models.Client;
import com.fdmgroup.cppapi.models.Consultant;
import com.fdmgroup.cppapi.models.Contact;
import com.fdmgroup.cppapi.models.Interest;
import com.fdmgroup.cppapi.models.Placement;
import com.fdmgroup.cppapi.models.Stream;
import com.fdmgroup.cppapi.repositories.AccountManagerRepository;
import com.fdmgroup.cppapi.repositories.ConsultantRepository;
import com.fdmgroup.cppapi.repositories.InterestRepository;
import com.fdmgroup.cppapi.repositories.PlacementRepository;

@Configuration
class LoadDatabase {

  private static final Logger log = Logger.getLogger(LoadDatabase.class.getName());

  @Bean
  CommandLineRunner initDatabase(AccountManagerRepository accountManagerRepository, ConsultantRepository consultantRepository, PlacementRepository placementRepository, InterestRepository interestRepository) {

    AccountManager frazerBarrell = new AccountManager("frazer.barrell@fdmgroup.com", "accountManager123!", new Contact("Frazer", "Barrell", "frazer.barrell@fdmgroup.com", "+440909090909", new Address("Oxford Street", "London", "London", "LONDON1", "United Kingdom")), "London", "NA");

    Consultant philParkinson= new Consultant("phil.parkinson@fdmgroup.com", "consultant123!", new Contact("Phil", "Parkinson", "phil.parkinson@fdmgroup.com", "+440909090909", new Address("Oxford Street", "London", "London", "LONDON1", "United Kingdom")), "", new Stream("AWS", true), "", "");

    List<Stream> streams = new ArrayList<Stream>();

    List<Interest> interests = new ArrayList<Interest>();

    Placement placement = new Placement("Software Developer", "Build awesome API's", new Client("Sky", "London", new Contact("Frazer", "Barrell", "frazer.barrell@fdmgroup.com", "+440909090909", new Address("Oxford Street", "London", "London", "LONDON1", "United Kingdom")), null), streams, interests);

    // Client client = new client ("philip.parkinson", "password1234", new Contact("Test5", "Agent", "testAgent@fdmgroup.com", "07595101202"), manager);

    AccountManager savedFrazerBarrell = accountManagerRepository.save(frazerBarrell);
    Consultant savedPhilParkinson = consultantRepository.save(philParkinson);
    Placement savedPlacement = placementRepository.save(placement);

    Interest interest = new Interest(savedPhilParkinson, savedPlacement, "Interested", "Really want to work at sky");

    Interest savedInterest = interestRepository.save(interest);

    return args -> {
      log.info("Loaded AccountManager " + savedFrazerBarrell);
      log.info("Loaded Consultant " + savedPhilParkinson);
      log.info("Loaded Placement " + savedPlacement);
      log.info("Loaded Interest " + savedInterest);
    };
  }
}