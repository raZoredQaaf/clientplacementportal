package com.fdmgroup.cppapi.exceptions;

public class ClientNotFoundException extends RuntimeException {

    public ClientNotFoundException(String id) {
        super("Could not find agent: " + id);
    }
}