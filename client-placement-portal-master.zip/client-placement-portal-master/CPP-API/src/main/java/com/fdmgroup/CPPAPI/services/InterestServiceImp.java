package com.fdmgroup.cppapi.services;

import org.springframework.stereotype.Service;

import com.fdmgroup.cppapi.models.Interest;
import com.fdmgroup.cppapi.repositories.InterestRepository;

@Service
public class InterestServiceImp implements InterestService{
	
private InterestRepository interestRepository;

	
	public InterestServiceImp(InterestRepository interestRepository) {
		this.interestRepository = interestRepository;
	}

	@Override
    public Interest addInterest(Interest interest) {
        // No id provided so will perform insert statement
        return this.interestRepository.save(interest);
    }

    @Override
    public Interest updateInterest(Interest interest) {
        // Id provided so will perform update statement
        return this.interestRepository.save(interest);
    }

    @Override
    public void deleteInterestById(Long id) {
        this.interestRepository.deleteById(id);
    }

    @Override
    public Iterable<Interest> getAllInterests() {
        return this.interestRepository.findAll();
    }

    @Override
    public Interest findInterestById(Long id) {
        return this.interestRepository.findById(id).orElse(null);
    }

	@Override
	public Iterable<Interest> findAllByPlacementId(Long id) {
		return this.interestRepository.findAllByPlacementId(id);
	}

	@Override
	public Iterable<Interest> findAllByConsultantId(Long id) {
		return this.interestRepository.findAllByConsultantId(id);
	}


}
