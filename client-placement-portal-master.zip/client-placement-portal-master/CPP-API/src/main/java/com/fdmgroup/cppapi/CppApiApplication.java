package com.fdmgroup.cppapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CppApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CppApiApplication.class, args);
	}

}
