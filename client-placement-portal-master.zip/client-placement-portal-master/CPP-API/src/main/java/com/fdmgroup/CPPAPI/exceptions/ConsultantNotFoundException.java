package com.fdmgroup.cppapi.exceptions;

public class ConsultantNotFoundException extends RuntimeException{
	public ConsultantNotFoundException(String email) {
        super("Could not find account: " + email);
    }
}
