package com.fdmgroup.cppapi.controllers;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fdmgroup.cppapi.exceptions.PlacementNotFoundException;
import com.fdmgroup.cppapi.models.Placement;
import com.fdmgroup.cppapi.services.PlacementService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/api/v1/placements")
public class PlacementController {

	private PlacementService placementsService;

	public PlacementController(PlacementService placementsService) {
		this.placementsService = placementsService;
	}
	
	@Operation(summary = "Create a new placements")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Placements created successfully", headers = {
			@Header(name = "location", description = "Uri to access to create placements") }, content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE) }) })
	
	@CrossOrigin(origins = "http://localhost:3000")
	@PostMapping
	public ResponseEntity<?> createPlacements(@Valid @RequestBody Placement placements, BindingResult bindingResult){
		
		if(bindingResult.hasErrors()) {
			Map<String, String> errors = new HashMap<>();
			
			for(FieldError error: bindingResult.getFieldErrors()) {
				errors.put(error.getField(), error.getDefaultMessage());
			}
			return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(this.placementsService.savePlacements(placements), HttpStatus.CREATED);
	}

	@Operation(summary = "Find All Placements")
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Find all placements successfully", headers = {
			@Header(name = "location", description = "Uri to access to find all placements")
		}, content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE)
		})
	})
	@CrossOrigin(origins = "http://localhost:3000")
	@GetMapping
	public ResponseEntity<?> getAllPlacements() {
		return new ResponseEntity<>(this.placementsService.getAllPlacements(), HttpStatus.OK);
	}
	
	@Operation(summary = "Find placements by id")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "find an placements successfully", headers = {
			@Header(name = "location", description = "Uri to access to find placements") }, content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE) }) })
	@CrossOrigin(origins = "http://localhost:3000")
	@GetMapping("/{id}")
	public ResponseEntity<?> findPlacementsById(@PathVariable Long id) {
		Placement placements = this.placementsService.findPlacementsById(id);

		if (placements == null) {
			return new ResponseEntity<>(
					new PlacementNotFoundException("The placements with id: " + id + " not found").getMessage(),
					HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(placements, HttpStatus.OK);
	}
	
	@Operation(summary = "Update an placements")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Placements updated successfully", headers = {
			@Header(name = "location", description = "Uri to access to update placements") }, content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE) }) })
	@CrossOrigin(origins = "http://localhost:3000")
	@PutMapping
	public ResponseEntity<?> updatePlacements(@RequestBody Placement placements) {
		return new ResponseEntity<>(this.placementsService.updatePlacements(placements), HttpStatus.OK);
	}
	
	@Operation(summary = "Delete an placements")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Placements deleted successfully", headers = {
			@Header(name = "location", description = "Uri to access to update placements") }, content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE) }) })
	@CrossOrigin(origins = "http://localhost:3000")
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deletePlacementsById(@PathVariable Long id) {
		Placement placements = this.placementsService.findPlacementsById(id);

		if (placements == null) {
			return new ResponseEntity<>(
					new PlacementNotFoundException("The placements with id: " + id + " not found").getMessage(),
					HttpStatus.NOT_FOUND);
		}

		this.placementsService.deletePlacementsById(id);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
}
