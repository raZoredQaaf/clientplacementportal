package com.fdmgroup.cppapi.models;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Builder;


@Entity(name = "Client")
public class Client {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "id_gen")
    @Column(name="client_id")
    private Long id;

    private String clientName;

    private String office;

    @OneToOne(cascade = CascadeType.ALL)
    private Contact contactPerson ;
    
    @OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name="client_placements", joinColumns=@JoinColumn(name="client_id"), inverseJoinColumns=@JoinColumn(name="placement_id"))
    @JsonIgnore
    private List<Placement> placements;

    public Client () {};

    @Builder
    public Client(
    String clientName,
    String office,
    Contact contactPerson,
    List<Placement> placements) {
        this.clientName = clientName;
        this.office = office;
        this.contactPerson = contactPerson;
        this.placements = placements;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getOffice() {
        return office;
    }

    public void setOffice(String office) {
        this.office = office;
    }

    public Contact getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(Contact contactPerson) {
        this.contactPerson = contactPerson;
    }

    public List<Placement> getPlacements() {
        return placements;
    }

    public void setPlacements(List<Placement> placements) {
        this.placements = placements;
    }

}
