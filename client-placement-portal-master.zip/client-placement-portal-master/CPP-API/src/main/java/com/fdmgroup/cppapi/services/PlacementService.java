package com.fdmgroup.cppapi.services;

import com.fdmgroup.cppapi.models.Placement;

public interface PlacementService {

    
    Placement findPlacementsById(Long id);

    Placement savePlacements(Placement placements);
	
	Placement updatePlacements(Placement placements);
	
	void deletePlacementsById(Long id);

    Iterable<Placement> getAllPlacements();
}
